#!usr/bin/env python

import rospy 
from std_msgs.msg import Float64
import sys, select, termios, tty
def getKey(key_timeout):
	settings = termios.tcgetattr(sys.stdin)
	tty.setraw(sys.stdin.fileno())
	rlist, _, _ = select.select([sys.stdin], [], [], key_timeout)
	if rlist:
		key = sys.stdin.read(1)
	else:
		key = ''
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	print("a")
	return key

f=Float64()
rospy.init_node('Commander_node')
rate = rospy.Rate(5)
command = "c"



def move_wheel(wheel_side,force):
	topic = "/bot/wheel_"+str(wheel_side)+"/command"
	pub = rospy.Publisher(topic,Float64,queue_size = 100)
	f.data = force
	pub.publish(f)

def l_wheels(torque):
	move_wheel("l",torque)

def r_wheels(torque):
	move_wheel("r",torque)

while not rospy.is_shutdown():
	
	if command == "w":
		l_wheels(600)
		r_wheels(600)
		print("Moving Forward")
		command = "c"

	elif command == "d":
		l_wheels(50)
		r_wheels(-50)
		print("Moving Right")
		command = "c"

	elif command == "a":
		l_wheels(-50)
		r_wheels(50)
		print("Moving Left")
		command = "c"

	elif command == "s":
		l_wheels(-60)
		r_wheels(-60)
		print("Moving back")
		command = "c"
	elif command == "q":
		l_wheels(0)
		r_wheels(0)
		print("stop")
		command = "c"

	else:
		command = getKey(100)	#press t to terminate control mode
		if command == "t":
			break
	rate.sleep()






